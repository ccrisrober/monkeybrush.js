/// <reference path="library/references.d.ts" />
// TODO: Texture LOD DEMO
import App from "./library/App";

import Core from "./library/core/core";
import Input from "./library/core/input";
import PostProcess from "./library/core/postProcess";
import utils from "./library/core/utils";
import Texture2D from "./library/textures/texture2d";
import CubeMapTexture from "./library/textures/cubeMapTexture";
// import Texture2DArray from "./library/textures/texture2dArray";
// import SimpleTexture2D from "./library/textures/simpleTexture2d";
import Program from "./library/core/program";

import Sphere from "./library/models/sphere";
import Cube from "./library/models/cube";
import Torus from "./library/models/torus";
import Disc from "./library/models/disc";
import Cone from "./library/models/cone";
import Cylinder from "./library/models/cylinder";
import Prism from "./library/models/prism";
import Mesh from "./library/models/mesh";

import VertexUBO from "./library/core/vertexUBO";
// import Framebuffer from "./library/core/framebuffer";
import ProgramManager from "./library/resources/programManager";
import ResourceMap from "./library/resources/resourceMap";
import loaders from "./library/resources/loaders";
import CustomModel from "./library/models/customModel";
import Timer from "./library/extras/timer";
import PointLight from "./library/lights/pointLight";
// import Vector2 from "./library/maths/vector2";
import Vector3 from "./library/maths/vector3";
import Camera2 from "./library/_demoCamera";

import ProgramCte from "./library/constants/ProgramCte";
// import TextureFormat from "./library/constants/TextureFormat";
import TextureType from "./library/constants/TextureType";

"use strict";

let camera = new Camera2(new Float32Array([-2.7, -1.4, 11.8]));

let SimpleConfig = function() {
    return {
        max: 10,
        resume: true,
        render: "0"
    };
};

let cubito: Cube;

let view;
let projection;

let customModel: CustomModel;

let identityMatrix = mat4.create();
mat4.identity(identityMatrix);
let model = mat4.create();
let angle = 0;

let tex: Texture2D;
let tex2: Texture2D;

let text = SimpleConfig();
function loadAssets() {
    loaders.loadImage("woodenBox.png", "woodenBox");
    loaders.loadImage("fragile.png", "fragile");
}

const mainShader: string = "progubo";

function initialize(app: App) {
    let woodenBox = ResourceMap.retrieveAsset("woodenBox");
    tex = new Texture2D(woodenBox, {
        flipY: true,
        minFilter: TextureType.Linear,
        magFilter: TextureType.Linear
    });
    tex.unbind();

    let fragile = ResourceMap.retrieveAsset("fragile");
    tex2 = new Texture2D(fragile, {
        flipY: true,
        minFilter: TextureType.Linear,
        magFilter: TextureType.Linear
    });
    tex2.unbind();

    cubito = new Cube(15.0);

    const webgl2 = app.webglVersion() === 2;

    ProgramManager.addWithFun("progubo", (): Program => {
        let prog: Program = new Program();
        prog.addShader(`#version 300 es
    precision highp float;

    layout(location = 0) in vec3 position;
    layout(location = 1) in vec3 normal;
    layout(location = 2) in vec2 uv;
    layout(location = 3) in vec3 offset;

    out vec2 outUV;

    uniform mat4 model;

    layout(std140, column_major) uniform;

    uniform UboDemo {
        mat4 projection;
        mat4 view;
    } ubo1;

    void main() {
        mat3 normalMatrix = mat3(inverse(transpose(model)));
        vec3 pos = position;
        vec4 pp = model * vec4(pos, 1.0);
        pp = ubo1.view * pp;
        outUV = uv;
        gl_Position = ubo1.projection * pp;
        gl_PointSize = 5.0;
    }`, ProgramCte.shader_type.vertex, ProgramCte.mode.read_text);
        prog.addShader(`#version 300 es
    precision highp float;

    out vec4 fragColor;

    in vec2 outUV;

    uniform sampler2D TexWood; // First Texture
    uniform sampler2D TexFragile; // Second Texture

    void main() {
        vec4 TextureFragile = texture(TexFragile, outUV);
        vec4 TextureWood = texture(TexWood, outUV);
        fragColor = mix(TextureWood,TextureFragile,TextureFragile.a);
    }
`, ProgramCte.shader_type.fragment, ProgramCte.mode.read_text);
        prog.compile();

        const gl = Core.getInstance().getGL();

        prog.use();

        var program = prog.program();

        uniformPerDrawBuffer = new VertexUBO(program, "UboDemo", 0);

        prog.addUniforms(["projection", "view", "model",
            "normalMatrix", "TexFragile", "TexWood"]);

        return prog;
    });

    const gl = Core.getInstance().getGL();

    //
    for (var i = 0; i < 10; ++i) {
        console.log(utils.random.nextInt(1, 6));
    }

    cameraUpdateCb();
};
var uniformPerDrawBuffer: VertexUBO;

function drawScene(app: App) {
    Core.getInstance().clearColorAndDepth();

    let prog = ProgramManager.get(mainShader);
    prog.use();

    tex.bind(0);
    prog.sendUniform1i("TexWood", 0);
    tex2.bind(1);
    prog.sendUniform1i("TexFragile", 1);

    let varvar = text.max;
    let i = 0, j = 0, k = 0;
    let dd = -1;

    const renderMode = text.render;
    let mode: string;
    switch (renderMode) {
        case "0":
            mode = "render";
            break;
        case "1":
            mode = "render2";
            break;
        case "2":
            mode = "render3";
            break;
    }

    for (i = -varvar; i < varvar; i += 5.0) {
        for (j = -varvar; j < varvar; j += 5.0) {
            for (k = -varvar; k < varvar; k += 5.0) {
                dd *= -1;
                mat4.translate(model, identityMatrix,
                    vec3.fromValues(i * 1.0, j * 1.0, k * 1.0));
                // mat4.rotateY(model, model, 90.0 * Math.PI / 180);
                mat4.rotateY(model, model, angle * dd);
                mat4.scale(model, model, vec3.fromValues(0.15, 0.15, 0.15));

                prog.sendUniformMat4("model", model);
                cubito[mode]();
            }
        }
    }
    //skybox.render(view, projection);
}

// ============================================================================================ //
// ============================================================================================ //
// ============================================================================================ //
// ============================================================================================ //
// ============================================================================================ //
// ============================================================================================ //

function cameraUpdateCb() {
    let canvas = Core.getInstance().canvas();
    view = camera.GetViewMatrix();
    projection = camera.GetProjectionMatrix(canvas.width, canvas.height);

    let prog = ProgramManager.get(mainShader);
    prog.use();

    let gl = Core.getInstance().getGL();

    var transforms = new Float32Array([]);
    transforms = utils.Float32Concat(transforms, projection);
    transforms = utils.Float32Concat(transforms, view);

    uniformPerDrawBuffer.update(transforms);
}

// @param dt: Global time in seconds
function updateScene(app: App, dt: number) {
    if (Input.getInstance().isButtonClicked(Input.mouseButton.Left)) {
        console.log("Mouse left clicked");
    }

    camera.timeElapsed = Timer.deltaTime() / 10.0;

    camera.update(cameraUpdateCb);

    angle += Timer.deltaTime() * 0.001;

};

/**/
window.onload = () => {
    new App({
        // title: "Demo appp",
        webglVersion: 2,
        loadAssets: loadAssets,
        initialize: initialize,
        update: updateScene,
        draw: drawScene,
        cameraUpdate: cameraUpdateCb,
        textCB: function(gui: dat.GUI) {
            gui.add(text, "max", 5, 100);
            gui.add(text, "render", {
                simple: 0,
                lines: 1,
                points: 2
            });
        }
    }, text).start();
};
