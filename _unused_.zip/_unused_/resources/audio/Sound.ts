class Sound {
    protected _volume: number = 1.0;
    protected _paused: boolean = false;

    public play() {
        // TODO
    }
    public pause() {
        // TODO
    }
    public stop() {
        // TODO
    }
    public fade() {
        // TODO
    }
    public fadeIn() {
        // TODO
    }
    public fadeOut() {
        // TODO
    }
    public isPlaying(): boolean { return true; }
}
