enum RotSeq {
    zyx, zyz, zxy, zxz, yxz, yxy, yzx, yzy, xyz, xyx, xzy, xzx
};

export { RotSeq };
