/// <reference path="library/references.d.ts" />
// TODO:
import * as MB from "./library/MonkeyBrush";

import { ProgramCte } from "./library/constants/ProgramCte";
// import { TextureType } from "./library/constants/TextureType";

"use strict";

let SimpleConfig = function() {
    return {
        max: 10,
        resume: true,
        render: "0",
        mode: 0
    };
};

class MyScene extends MB.Scene {
    protected camera = new MB.Camera2(new MB.Vect3(-2.7, -1.4, 11.8));

    protected cubito: MB.Icosphere;
    protected floor: MB.Floor;
    protected skybox: MB.Skybox;
    protected view;
    protected projection;

    protected identityMatrix;
    protected model;
    protected angle = 0;

    constructor() {
        super(SimpleConfig(), "App", 2);
        this.identityMatrix = MB.Mat4.identity;
        this.model = new MB.Mat4();
    }

    protected mainShader: string = "prepass";

    loadAssets() {
        // skybox
        MB.loaders.loadImage("assets/images/skybox2/back.jpg");
        MB.loaders.loadImage("assets/images/skybox2/bottom.jpg");
        MB.loaders.loadImage("assets/images/skybox2/front.jpg");
        MB.loaders.loadImage("assets/images/skybox2/left.jpg");
        MB.loaders.loadImage("assets/images/skybox2/right.jpg");
        MB.loaders.loadImage("assets/images/skybox2/top.jpg");

        MB.loaders.loadImage("descarga (2).png", "descarga");
        MB.loaders.loadImage("heightmap.png", "heightmap");
        MB.loaders.loadImage("grass.png", "grass");
    }
    protected tex2d: MB.Texture2D;
    protected tex2d2: MB.Texture2D;
    protected deferred: MB.GBuffer;
    initialize() {
        this.skybox = new MB.Skybox("assets/images/skybox2", false);

        let grassImage = MB.ResourceMap.retrieveAsset("grass");
        this.tex2d = new MB.Texture2D(grassImage, {
            flipY: true,
            minFilter: MB.TextureType.Linear,
            magFilter: MB.TextureType.Linear,
            wrapS: MB.TextureType.Clamp2Edge,
            wrapT: MB.TextureType.Clamp2Edge
        });

        let heightmapImage = MB.ResourceMap.retrieveAsset("descarga");
        this.tex2d2 = new MB.Texture2D(heightmapImage, {
            flipY: true,
            minFilter: MB.TextureType.Nearest,
            magFilter: MB.TextureType.Nearest,
            wrapS: MB.TextureType.MirroredRepeat,
            wrapT: MB.TextureType.MirroredRepeat
        });

        this.cubito = new MB.Icosphere(15.0, 1.0);
        this.floor = new MB.Floor(82.0);

        let canvas: HTMLCanvasElement = MB.Core.getInstance().canvas();
        this.deferred = new MB.GBuffer(new MB.Vect2(
            canvas.width,
            canvas.height
        ));

        MB.ProgramManager.addWithFun("prepass", (): MB.Program => {
            let prog: MB.Program = new MB.Program();
            prog.addShader("./shaders/gBufferShader.vert",
                ProgramCte.shader_type.vertex, ProgramCte.mode.read_file);
            prog.addShader("./shaders/gBufferShader.frag",
                ProgramCte.shader_type.fragment, ProgramCte.mode.read_file);
            prog.compile();

            prog.addUniforms(["tex", "usemc"]);

            prog.addUniforms(["projection", "view", "model", "normalMatrix"]);

            return prog;
        });

        MB.ProgramManager.addWithFun("pp", (): MB.Program => {
            let prog: MB.Program = new MB.Program();
            prog.addShader("./shaders/postprocessShader.vert",
                ProgramCte.shader_type.vertex, ProgramCte.mode.read_file);
            prog.addShader("./shaders/postprocessShader.frag",
                ProgramCte.shader_type.fragment, ProgramCte.mode.read_file);
            prog.compile();

            prog.addUniforms(["time"]);
            prog.addUniforms(["mode"]);
            prog.addUniforms(["gPosition", "gNormal", "gAlbedoSpec"]);

            prog.use();

            prog.sendUniform1i("gPosition", 0);
            prog.sendUniform1i("gNormal", 1);
            prog.sendUniform1i("gAlbedoSpec", 2);
            console.log(prog.uniformLocations);
            return prog;
        });

        /*MB.ProgramManager.addWithFun("prog", (): MB.Program => {
            let prog: MB.Program = new MB.Program();
            prog.addShader(
        `#version 300 es
        precision highp float;

        layout(location = 0) in vec3 position;
        layout(location = 1) in vec3 normal;
        layout(location = 2) in vec2 uv_;

        uniform mat4 projection;
        uniform mat4 view;
        uniform mat4 model;

        out vec3 outPosition;
        out vec3 outNormal;
        out vec2 uv;

        void main() {
            mat3 normalMatrix = mat3(inverse(transpose(model)));

            gl_Position = projection * view * model * vec4(position, 1.0f);
            outNormal = mat3(transpose(inverse(model))) * normal;
            outPosition = vec3(model * vec4(position, 1.0f));

            uv = uv_;

            gl_PointSize = 5.0;
        }`, ProgramCte.shader_type.vertex, ProgramCte.mode.read_text);
            prog.addShader(
        `#version 300 es
        precision highp float;

        in vec3 outNormal;
        in vec3 outPosition;
        in vec2 uv;

        out vec4 fragColor;

        uniform vec3 cameraPos;
        uniform sampler2D tex;

        void main() {
            fragColor = texture(tex, uv);
        }`, ProgramCte.shader_type.fragment, ProgramCte.mode.read_text);
            prog.compile();

            prog.use();

            prog.addUniforms(["projection", "view", "model", "tex"]);

            return prog;
        });*/

        this.cameraUpdate();
    }
    update(dt: number) {
        if (MB.Input.getInstance().isButtonClicked(MB.Input.mouseButton.Left)) {
            console.log("Mouse left clicked");
        }

        this.camera.timeElapsed = MB.Timer.deltaTime() / 10.0;

        this.camera.update(this.cameraUpdate.bind(this));

        this.angle += MB.Timer.deltaTime() * 0.001;
    }
    draw(dt?: number) {
        MB.Core.getInstance().clearColorAndDepth();

        this.deferred.bindForWriting();
        MB.Core.getInstance().clearColorAndDepth();

        let prog = MB.ProgramManager.get(this.mainShader);
        prog.use();

        let varvar = this.text.max;
        let i = 0, j = 0, k = 0;
        let dd = -1;

        this.tex2d2.bind(0);
        prog.sendUniform1i("tex", 0);

        const renderMode = this.text.render;
        let mode: string;
        switch (renderMode) {
            case "0":
                mode = "render";
                break;
            case "1":
                mode = "render2";
                break;
            case "2":
                mode = "render3";
                break;
        }

        const renderDrawMode = this.text.mode;
        let drawMode: number;
        switch (renderDrawMode) {
            case "0":
                drawMode = 0;
                break;
            case "1":
                drawMode = 1;
                break;
            case "2":
                drawMode = 2;
                break;
            case "3":
                drawMode = 3;
                break;
            case "4":
                drawMode = 4;
                break;
        }

        const gl = MB.Core.getInstance().getGL();
        gl.enable(gl.DEPTH_TEST);
        gl.depthFunc(gl.LEQUAL);

        for (i = -varvar; i < varvar; i += 10.0) {
            for (j = -varvar; j < varvar; j += 10.0) {
                for (k = -varvar; k < varvar; k += 10.0) {
                    dd *= -1;
                    this.model =
                        this.model
                            .reset()
                            .translate(new MB.Vect3(i * 1.0, j * 1.0, k * 1.0))
                            .rotate(90.0 * Math.PI / 180, MB.Vect3.yAxis)
                            .rotate(this.angle * 0.5 * dd, MB.Vect3.yAxis)
                            .scale(new MB.Vect3(0.25, 0.25, 0.25));
                    prog.sendUniformMat4("model", this.model);
                    this.cubito[mode]();
                }
            }
        }
        this.model = this.model.reset().translate(new MB.Vect3());

        prog.sendUniformMat4("model", this.model);
        this.floor.render();
        this.deferred.bindForReading();
        MB.Core.getInstance().clearColorAndDepth();
        var prog2 = MB.ProgramManager.get("pp");
        prog2.use();
        prog2.sendUniform1i("mode", drawMode);
        MB.PostProcess.render();
    }
    cameraUpdate() {
        let canvas = MB.Core.getInstance().canvas();
        this.view = this.camera.GetViewMatrix();
        this.projection = this.camera.GetProjectionMatrix(canvas.width, canvas.height);

        let prog = MB.ProgramManager.get(this.mainShader);
        prog.use();

        prog.sendUniformVec3("viewPos", this.camera.GetPos());
        prog.sendUniformMat4("projection", this.projection);
        prog.sendUniformMat4("view", this.view);
    }
    textCB(gui: dat.GUI) {
        gui.add(this.text, "max", 5, 100);
        gui.add(this.text, "render", {
            simple: 0,
            lines: 1,
            points: 2
        });
        gui.add(this.text, "mode", {
            simple: 0,
            position: 1,
            normal: 2,
            diffuse: 3,
            depth: 4,
        });
    }
};

window.onload = () => {
    let myScene: MyScene = new MyScene();
    myScene.start();
};
